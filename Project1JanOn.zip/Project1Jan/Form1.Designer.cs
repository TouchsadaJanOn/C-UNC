﻿namespace Project1Jan
{
    partial class frmProject1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDisplay = new System.Windows.Forms.Label();
            this.radBlue = new System.Windows.Forms.RadioButton();
            this.radRed = new System.Windows.Forms.RadioButton();
            this.radWhite = new System.Windows.Forms.RadioButton();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.grpSelection = new System.Windows.Forms.GroupBox();
            this.txtDisplayText = new System.Windows.Forms.TextBox();
            this.radHello = new System.Windows.Forms.RadioButton();
            this.radBonjour = new System.Windows.Forms.RadioButton();
            this.radHola = new System.Windows.Forms.RadioButton();
            this.radClear = new System.Windows.Forms.RadioButton();
            this.grpSelection.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblDisplay
            // 
            this.lblDisplay.AutoSize = true;
            this.lblDisplay.Location = new System.Drawing.Point(36, 40);
            this.lblDisplay.Name = "lblDisplay";
            this.lblDisplay.Size = new System.Drawing.Size(156, 16);
            this.lblDisplay.TabIndex = 0;
            this.lblDisplay.Text = "Pick a background color.";
            // 
            // radBlue
            // 
            this.radBlue.AutoSize = true;
            this.radBlue.Location = new System.Drawing.Point(39, 98);
            this.radBlue.Name = "radBlue";
            this.radBlue.Size = new System.Drawing.Size(53, 20);
            this.radBlue.TabIndex = 1;
            this.radBlue.TabStop = true;
            this.radBlue.Text = "&Blue";
            this.radBlue.UseVisualStyleBackColor = true;
            // 
            // radRed
            // 
            this.radRed.AutoSize = true;
            this.radRed.Location = new System.Drawing.Point(140, 98);
            this.radRed.Name = "radRed";
            this.radRed.Size = new System.Drawing.Size(52, 20);
            this.radRed.TabIndex = 2;
            this.radRed.TabStop = true;
            this.radRed.Text = "&Red";
            this.radRed.UseVisualStyleBackColor = true;
            // 
            // radWhite
            // 
            this.radWhite.AutoSize = true;
            this.radWhite.Location = new System.Drawing.Point(231, 98);
            this.radWhite.Name = "radWhite";
            this.radWhite.Size = new System.Drawing.Size(60, 20);
            this.radWhite.TabIndex = 3;
            this.radWhite.TabStop = true;
            this.radWhite.Text = "&White";
            this.radWhite.UseVisualStyleBackColor = true;
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(440, 52);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(75, 23);
            this.btnDisplay.TabIndex = 4;
            this.btnDisplay.Text = "&Display";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.BtnDisplay_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(440, 109);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(231, 446);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // grpSelection
            // 
            this.grpSelection.Controls.Add(this.radClear);
            this.grpSelection.Controls.Add(this.radHola);
            this.grpSelection.Controls.Add(this.radBonjour);
            this.grpSelection.Controls.Add(this.radHello);
            this.grpSelection.Controls.Add(this.txtDisplayText);
            this.grpSelection.Location = new System.Drawing.Point(39, 166);
            this.grpSelection.Name = "grpSelection";
            this.grpSelection.Size = new System.Drawing.Size(476, 252);
            this.grpSelection.TabIndex = 7;
            this.grpSelection.TabStop = false;
            this.grpSelection.Text = "Select One Option";
            // 
            // txtDisplayText
            // 
            this.txtDisplayText.Location = new System.Drawing.Point(180, 74);
            this.txtDisplayText.Name = "txtDisplayText";
            this.txtDisplayText.Size = new System.Drawing.Size(100, 22);
            this.txtDisplayText.TabIndex = 0;
            // 
            // radHello
            // 
            this.radHello.AutoSize = true;
            this.radHello.Location = new System.Drawing.Point(27, 146);
            this.radHello.Name = "radHello";
            this.radHello.Size = new System.Drawing.Size(58, 20);
            this.radHello.TabIndex = 1;
            this.radHello.TabStop = true;
            this.radHello.Text = "&Hello";
            this.radHello.UseVisualStyleBackColor = true;
            this.radHello.CheckedChanged += new System.EventHandler(this.RadioButton1_CheckedChanged);
            // 
            // radBonjour
            // 
            this.radBonjour.AutoSize = true;
            this.radBonjour.Location = new System.Drawing.Point(147, 146);
            this.radBonjour.Name = "radBonjour";
            this.radBonjour.Size = new System.Drawing.Size(72, 20);
            this.radBonjour.TabIndex = 2;
            this.radBonjour.TabStop = true;
            this.radBonjour.Text = "&Bonjour";
            this.radBonjour.UseVisualStyleBackColor = true;
            this.radBonjour.CheckedChanged += new System.EventHandler(this.RadioButton2_CheckedChanged);
            // 
            // radHola
            // 
            this.radHola.AutoSize = true;
            this.radHola.Location = new System.Drawing.Point(255, 148);
            this.radHola.Name = "radHola";
            this.radHola.Size = new System.Drawing.Size(58, 20);
            this.radHola.TabIndex = 3;
            this.radHola.TabStop = true;
            this.radHola.Text = " &Hola";
            this.radHola.UseVisualStyleBackColor = true;
            this.radHola.CheckedChanged += new System.EventHandler(this.RadHola_CheckedChanged);
            // 
            // radClear
            // 
            this.radClear.AutoSize = true;
            this.radClear.Location = new System.Drawing.Point(373, 150);
            this.radClear.Name = "radClear";
            this.radClear.Size = new System.Drawing.Size(58, 20);
            this.radClear.TabIndex = 4;
            this.radClear.TabStop = true;
            this.radClear.Text = "&Clear";
            this.radClear.UseVisualStyleBackColor = true;
            this.radClear.CheckedChanged += new System.EventHandler(this.RadClear_CheckedChanged);
            // 
            // frmProject1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 554);
            this.Controls.Add(this.grpSelection);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.radWhite);
            this.Controls.Add(this.radRed);
            this.Controls.Add(this.radBlue);
            this.Controls.Add(this.lblDisplay);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmProject1";
            this.Text = "Project1";
            this.grpSelection.ResumeLayout(false);
            this.grpSelection.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDisplay;
        private System.Windows.Forms.RadioButton radBlue;
        private System.Windows.Forms.RadioButton radRed;
        private System.Windows.Forms.RadioButton radWhite;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.GroupBox grpSelection;
        private System.Windows.Forms.RadioButton radClear;
        private System.Windows.Forms.RadioButton radHola;
        private System.Windows.Forms.RadioButton radBonjour;
        private System.Windows.Forms.RadioButton radHello;
        private System.Windows.Forms.TextBox txtDisplayText;
    }
}

