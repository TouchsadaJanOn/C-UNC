﻿namespace Project2JanOn
{
    partial class frmTaxCalc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtGrossIncome = new System.Windows.Forms.TextBox();
            this.txtNetIncome = new System.Windows.Forms.TextBox();
            this.txtFederalTax = new System.Windows.Forms.TextBox();
            this.txtStateTax = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblGrossIncome = new System.Windows.Forms.Label();
            this.lblStateTax = new System.Windows.Forms.Label();
            this.lblFederalTax = new System.Windows.Forms.Label();
            this.lblNetIncome = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtGrossIncome
            // 
            this.txtGrossIncome.Location = new System.Drawing.Point(334, 66);
            this.txtGrossIncome.Name = "txtGrossIncome";
            this.txtGrossIncome.Size = new System.Drawing.Size(186, 20);
            this.txtGrossIncome.TabIndex = 0;
            // 
            // txtNetIncome
            // 
            this.txtNetIncome.Location = new System.Drawing.Point(334, 269);
            this.txtNetIncome.Name = "txtNetIncome";
            this.txtNetIncome.Size = new System.Drawing.Size(186, 20);
            this.txtNetIncome.TabIndex = 1;
            // 
            // txtFederalTax
            // 
            this.txtFederalTax.Location = new System.Drawing.Point(334, 203);
            this.txtFederalTax.Name = "txtFederalTax";
            this.txtFederalTax.Size = new System.Drawing.Size(186, 20);
            this.txtFederalTax.TabIndex = 2;
            // 
            // txtStateTax
            // 
            this.txtStateTax.Location = new System.Drawing.Point(334, 129);
            this.txtStateTax.Name = "txtStateTax";
            this.txtStateTax.Size = new System.Drawing.Size(186, 20);
            this.txtStateTax.TabIndex = 3;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculate.Location = new System.Drawing.Point(609, 129);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(130, 52);
            this.btnCalculate.TabIndex = 2;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.BtnCalculate_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(468, 348);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(89, 37);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(278, 348);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(87, 37);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // lblGrossIncome
            // 
            this.lblGrossIncome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGrossIncome.Location = new System.Drawing.Point(78, 66);
            this.lblGrossIncome.Name = "lblGrossIncome";
            this.lblGrossIncome.Size = new System.Drawing.Size(168, 20);
            this.lblGrossIncome.TabIndex = 7;
            this.lblGrossIncome.Text = "Enter Gross Income: ";
            // 
            // lblStateTax
            // 
            this.lblStateTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStateTax.Location = new System.Drawing.Point(78, 129);
            this.lblStateTax.Name = "lblStateTax";
            this.lblStateTax.Size = new System.Drawing.Size(168, 20);
            this.lblStateTax.TabIndex = 8;
            this.lblStateTax.Text = "State Tax:";
            // 
            // lblFederalTax
            // 
            this.lblFederalTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFederalTax.Location = new System.Drawing.Point(78, 201);
            this.lblFederalTax.Name = "lblFederalTax";
            this.lblFederalTax.Size = new System.Drawing.Size(168, 20);
            this.lblFederalTax.TabIndex = 9;
            this.lblFederalTax.Text = "Federal Tax:";
            // 
            // lblNetIncome
            // 
            this.lblNetIncome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNetIncome.Location = new System.Drawing.Point(78, 269);
            this.lblNetIncome.Name = "lblNetIncome";
            this.lblNetIncome.Size = new System.Drawing.Size(168, 20);
            this.lblNetIncome.TabIndex = 10;
            this.lblNetIncome.Text = "Net Income:";
            // 
            // frmTaxCalc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblNetIncome);
            this.Controls.Add(this.lblFederalTax);
            this.Controls.Add(this.lblStateTax);
            this.Controls.Add(this.lblGrossIncome);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtStateTax);
            this.Controls.Add(this.txtFederalTax);
            this.Controls.Add(this.txtNetIncome);
            this.Controls.Add(this.txtGrossIncome);
            this.Name = "frmTaxCalc";
            this.Text = "Project 2 - Tax Calc";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtGrossIncome;
        private System.Windows.Forms.TextBox txtNetIncome;
        private System.Windows.Forms.TextBox txtFederalTax;
        private System.Windows.Forms.TextBox txtStateTax;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblGrossIncome;
        private System.Windows.Forms.Label lblStateTax;
        private System.Windows.Forms.Label lblFederalTax;
        private System.Windows.Forms.Label lblNetIncome;
    }
}

