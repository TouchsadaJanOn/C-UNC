﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project2JanOn
{
    public partial class frmTaxCalc : Form
    {
        public frmTaxCalc()
        {
            InitializeComponent();
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            txtGrossIncome.Focus();
            txtFederalTax.Text = "0";
            txtGrossIncome.Text = " ";
            txtNetIncome.Text = "0";
            txtStateTax.Text = "0";
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
            double GrossIncome;
            double StateTax;
            double FedTax;
            double NetIcome;

            GrossIncome = double.Parse(txtGrossIncome.Text);

            if (GrossIncome >= 0)
            {
                StateTax = GrossIncome * .02;
                txtStateTax.Text = StateTax.ToString("c");
                FedTax = GrossIncome * .07;
                txtFederalTax.Text = FedTax.ToString("c");
                NetIcome = GrossIncome - StateTax - FedTax;
                txtNetIncome.Text = NetIcome.ToString("c");
            }
            else
            {
                MessageBox.Show("Must Be A Positive Number!");
                
                }
            }
            catch
            {
                MessageBox.Show("Error- Input must be a numeric value");
            }
            
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
           
        }
    }
}
