﻿namespace Project3JanOn
{
    partial class frmProject3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProject3));
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.grpbxNutrition = new System.Windows.Forms.GroupBox();
            this.lblChickenSandwich = new System.Windows.Forms.Label();
            this.lblChickenSalad = new System.Windows.Forms.Label();
            this.lblWaffleFries = new System.Windows.Forms.Label();
            this.lblChickenNuggets = new System.Windows.Forms.Label();
            this.lblDrPepper = new System.Windows.Forms.Label();
            this.lblCola = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.picSandwich = new System.Windows.Forms.PictureBox();
            this.picSalad = new System.Windows.Forms.PictureBox();
            this.picFries = new System.Windows.Forms.PictureBox();
            this.picNuggets = new System.Windows.Forms.PictureBox();
            this.picCola = new System.Windows.Forms.PictureBox();
            this.picDrPepper = new System.Windows.Forms.PictureBox();
            this.lblProtein = new System.Windows.Forms.Label();
            this.lblFat = new System.Windows.Forms.Label();
            this.lblSodium = new System.Windows.Forms.Label();
            this.lblCal = new System.Windows.Forms.Label();
            this.txtCal = new System.Windows.Forms.TextBox();
            this.txtSodium = new System.Windows.Forms.TextBox();
            this.txtFat = new System.Windows.Forms.TextBox();
            this.txtProtein = new System.Windows.Forms.TextBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.lstOrder = new System.Windows.Forms.ListBox();
            this.grpbxNutrition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSandwich)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSalad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFries)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNuggets)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCola)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDrPepper)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(601, 387);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(77, 27);
            this.btnClear.TabIndex = 0;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(703, 387);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(73, 27);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // grpbxNutrition
            // 
            this.grpbxNutrition.BackColor = System.Drawing.Color.White;
            this.grpbxNutrition.Controls.Add(this.txtProtein);
            this.grpbxNutrition.Controls.Add(this.txtFat);
            this.grpbxNutrition.Controls.Add(this.txtSodium);
            this.grpbxNutrition.Controls.Add(this.txtCal);
            this.grpbxNutrition.Controls.Add(this.lblProtein);
            this.grpbxNutrition.Controls.Add(this.lblFat);
            this.grpbxNutrition.Controls.Add(this.lblSodium);
            this.grpbxNutrition.Controls.Add(this.lblCal);
            this.grpbxNutrition.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbxNutrition.Location = new System.Drawing.Point(12, 357);
            this.grpbxNutrition.Name = "grpbxNutrition";
            this.grpbxNutrition.Size = new System.Drawing.Size(460, 90);
            this.grpbxNutrition.TabIndex = 2;
            this.grpbxNutrition.TabStop = false;
            this.grpbxNutrition.Text = "Nutrition Totals";
            // 
            // lblChickenSandwich
            // 
            this.lblChickenSandwich.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChickenSandwich.Location = new System.Drawing.Point(21, 23);
            this.lblChickenSandwich.Name = "lblChickenSandwich";
            this.lblChickenSandwich.Size = new System.Drawing.Size(191, 24);
            this.lblChickenSandwich.TabIndex = 3;
            this.lblChickenSandwich.Text = "Chicken Sandwich $3.15";
            // 
            // lblChickenSalad
            // 
            this.lblChickenSalad.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChickenSalad.Location = new System.Drawing.Point(268, 189);
            this.lblChickenSalad.Name = "lblChickenSalad";
            this.lblChickenSalad.Size = new System.Drawing.Size(191, 24);
            this.lblChickenSalad.TabIndex = 4;
            this.lblChickenSalad.Text = "Chicken Salad $7.19";
            // 
            // lblWaffleFries
            // 
            this.lblWaffleFries.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWaffleFries.Location = new System.Drawing.Point(21, 189);
            this.lblWaffleFries.Name = "lblWaffleFries";
            this.lblWaffleFries.Size = new System.Drawing.Size(191, 24);
            this.lblWaffleFries.TabIndex = 5;
            this.lblWaffleFries.Text = "Waffle Fries $1.85";
            this.lblWaffleFries.Click += new System.EventHandler(this.LblWaffleFries_Click);
            // 
            // lblChickenNuggets
            // 
            this.lblChickenNuggets.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChickenNuggets.Location = new System.Drawing.Point(262, 23);
            this.lblChickenNuggets.Name = "lblChickenNuggets";
            this.lblChickenNuggets.Size = new System.Drawing.Size(191, 24);
            this.lblChickenNuggets.TabIndex = 6;
            this.lblChickenNuggets.Text = "Chicken Nuggets $4.75";
            // 
            // lblDrPepper
            // 
            this.lblDrPepper.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDrPepper.Location = new System.Drawing.Point(458, 188);
            this.lblDrPepper.Name = "lblDrPepper";
            this.lblDrPepper.Size = new System.Drawing.Size(144, 34);
            this.lblDrPepper.TabIndex = 7;
            this.lblDrPepper.Text = "Dr. Pepper   $2.75";
            this.lblDrPepper.Click += new System.EventHandler(this.LblDrPepper_Click);
            // 
            // lblCola
            // 
            this.lblCola.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCola.Location = new System.Drawing.Point(493, 23);
            this.lblCola.Name = "lblCola";
            this.lblCola.Size = new System.Drawing.Size(100, 24);
            this.lblCola.TabIndex = 8;
            this.lblCola.Text = "Cola $2.75";
            // 
            // lblTotal
            // 
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(636, 23);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(100, 24);
            this.lblTotal.TabIndex = 9;
            this.lblTotal.Text = "Total:";
            // 
            // picSandwich
            // 
            this.picSandwich.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picSandwich.Image = ((System.Drawing.Image)(resources.GetObject("picSandwich.Image")));
            this.picSandwich.Location = new System.Drawing.Point(12, 50);
            this.picSandwich.Name = "picSandwich";
            this.picSandwich.Size = new System.Drawing.Size(224, 133);
            this.picSandwich.TabIndex = 10;
            this.picSandwich.TabStop = false;
            this.picSandwich.Click += new System.EventHandler(this.PicSandwich_Click);
            // 
            // picSalad
            // 
            this.picSalad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picSalad.Image = ((System.Drawing.Image)(resources.GetObject("picSalad.Image")));
            this.picSalad.Location = new System.Drawing.Point(251, 213);
            this.picSalad.Name = "picSalad";
            this.picSalad.Size = new System.Drawing.Size(221, 138);
            this.picSalad.TabIndex = 11;
            this.picSalad.TabStop = false;
            this.picSalad.Click += new System.EventHandler(this.PicSalad_Click);
            // 
            // picFries
            // 
            this.picFries.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picFries.Image = ((System.Drawing.Image)(resources.GetObject("picFries.Image")));
            this.picFries.Location = new System.Drawing.Point(12, 213);
            this.picFries.Name = "picFries";
            this.picFries.Size = new System.Drawing.Size(224, 138);
            this.picFries.TabIndex = 12;
            this.picFries.TabStop = false;
            this.picFries.Click += new System.EventHandler(this.PicFries_Click);
            // 
            // picNuggets
            // 
            this.picNuggets.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picNuggets.Image = ((System.Drawing.Image)(resources.GetObject("picNuggets.Image")));
            this.picNuggets.Location = new System.Drawing.Point(251, 50);
            this.picNuggets.Name = "picNuggets";
            this.picNuggets.Size = new System.Drawing.Size(223, 133);
            this.picNuggets.TabIndex = 13;
            this.picNuggets.TabStop = false;
            this.picNuggets.Click += new System.EventHandler(this.PicNuggets_Click);
            // 
            // picCola
            // 
            this.picCola.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCola.Image = ((System.Drawing.Image)(resources.GetObject("picCola.Image")));
            this.picCola.Location = new System.Drawing.Point(494, 50);
            this.picCola.Name = "picCola";
            this.picCola.Size = new System.Drawing.Size(85, 133);
            this.picCola.TabIndex = 14;
            this.picCola.TabStop = false;
            this.picCola.Click += new System.EventHandler(this.PicCola_Click);
            // 
            // picDrPepper
            // 
            this.picDrPepper.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picDrPepper.Image = ((System.Drawing.Image)(resources.GetObject("picDrPepper.Image")));
            this.picDrPepper.Location = new System.Drawing.Point(496, 213);
            this.picDrPepper.Name = "picDrPepper";
            this.picDrPepper.Size = new System.Drawing.Size(83, 138);
            this.picDrPepper.TabIndex = 15;
            this.picDrPepper.TabStop = false;
            this.picDrPepper.Click += new System.EventHandler(this.PicDrPepper_Click);
            // 
            // lblProtein
            // 
            this.lblProtein.BackColor = System.Drawing.SystemColors.Control;
            this.lblProtein.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProtein.Location = new System.Drawing.Point(306, 22);
            this.lblProtein.Name = "lblProtein";
            this.lblProtein.Size = new System.Drawing.Size(67, 24);
            this.lblProtein.TabIndex = 16;
            this.lblProtein.Text = "Protein";
            this.lblProtein.Click += new System.EventHandler(this.LblProtein_Click);
            // 
            // lblFat
            // 
            this.lblFat.BackColor = System.Drawing.SystemColors.Control;
            this.lblFat.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFat.Location = new System.Drawing.Point(221, 22);
            this.lblFat.Name = "lblFat";
            this.lblFat.Size = new System.Drawing.Size(51, 24);
            this.lblFat.TabIndex = 17;
            this.lblFat.Text = "Fat";
            this.lblFat.Click += new System.EventHandler(this.LblFat_Click);
            // 
            // lblSodium
            // 
            this.lblSodium.BackColor = System.Drawing.SystemColors.Control;
            this.lblSodium.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSodium.Location = new System.Drawing.Point(131, 22);
            this.lblSodium.Name = "lblSodium";
            this.lblSodium.Size = new System.Drawing.Size(69, 24);
            this.lblSodium.TabIndex = 18;
            this.lblSodium.Text = "Sodium";
            // 
            // lblCal
            // 
            this.lblCal.BackColor = System.Drawing.SystemColors.Control;
            this.lblCal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCal.Location = new System.Drawing.Point(9, 22);
            this.lblCal.Name = "lblCal";
            this.lblCal.Size = new System.Drawing.Size(100, 24);
            this.lblCal.TabIndex = 19;
            this.lblCal.Text = "Calories";
            // 
            // txtCal
            // 
            this.txtCal.Location = new System.Drawing.Point(12, 46);
            this.txtCal.Name = "txtCal";
            this.txtCal.Size = new System.Drawing.Size(88, 26);
            this.txtCal.TabIndex = 20;
            // 
            // txtSodium
            // 
            this.txtSodium.Location = new System.Drawing.Point(132, 47);
            this.txtSodium.Name = "txtSodium";
            this.txtSodium.Size = new System.Drawing.Size(51, 26);
            this.txtSodium.TabIndex = 21;
            // 
            // txtFat
            // 
            this.txtFat.Location = new System.Drawing.Point(221, 47);
            this.txtFat.Name = "txtFat";
            this.txtFat.Size = new System.Drawing.Size(48, 26);
            this.txtFat.TabIndex = 22;
            // 
            // txtProtein
            // 
            this.txtProtein.Location = new System.Drawing.Point(306, 47);
            this.txtProtein.Name = "txtProtein";
            this.txtProtein.Size = new System.Drawing.Size(67, 26);
            this.txtProtein.TabIndex = 23;
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(677, 23);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(59, 20);
            this.txtTotal.TabIndex = 24;
            // 
            // lstOrder
            // 
            this.lstOrder.FormattingEnabled = true;
            this.lstOrder.Location = new System.Drawing.Point(599, 49);
            this.lstOrder.Name = "lstOrder";
            this.lstOrder.Size = new System.Drawing.Size(177, 303);
            this.lstOrder.TabIndex = 26;
            // 
            // frmProject3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 458);
            this.Controls.Add(this.lstOrder);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.picDrPepper);
            this.Controls.Add(this.picCola);
            this.Controls.Add(this.picNuggets);
            this.Controls.Add(this.picFries);
            this.Controls.Add(this.picSalad);
            this.Controls.Add(this.picSandwich);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblCola);
            this.Controls.Add(this.lblDrPepper);
            this.Controls.Add(this.lblChickenNuggets);
            this.Controls.Add(this.lblWaffleFries);
            this.Controls.Add(this.lblChickenSalad);
            this.Controls.Add(this.lblChickenSandwich);
            this.Controls.Add(this.grpbxNutrition);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Name = "frmProject3";
            this.Text = "Project 3 - Menu";
            this.Load += new System.EventHandler(this.FrmProject3_Load);
            this.grpbxNutrition.ResumeLayout(false);
            this.grpbxNutrition.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSandwich)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSalad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFries)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNuggets)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCola)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDrPepper)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.GroupBox grpbxNutrition;
        private System.Windows.Forms.Label lblChickenSandwich;
        private System.Windows.Forms.Label lblChickenSalad;
        private System.Windows.Forms.Label lblWaffleFries;
        private System.Windows.Forms.Label lblChickenNuggets;
        private System.Windows.Forms.Label lblDrPepper;
        private System.Windows.Forms.Label lblCola;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.PictureBox picSandwich;
        private System.Windows.Forms.PictureBox picSalad;
        private System.Windows.Forms.PictureBox picFries;
        private System.Windows.Forms.PictureBox picNuggets;
        private System.Windows.Forms.PictureBox picCola;
        private System.Windows.Forms.PictureBox picDrPepper;
        private System.Windows.Forms.TextBox txtProtein;
        private System.Windows.Forms.TextBox txtFat;
        private System.Windows.Forms.TextBox txtSodium;
        private System.Windows.Forms.TextBox txtCal;
        private System.Windows.Forms.Label lblProtein;
        private System.Windows.Forms.Label lblFat;
        private System.Windows.Forms.Label lblSodium;
        private System.Windows.Forms.Label lblCal;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.ListBox lstOrder;
    }
}

