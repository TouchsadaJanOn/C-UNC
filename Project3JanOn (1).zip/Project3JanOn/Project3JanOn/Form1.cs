﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project3JanOn
{
    public partial class frmProject3 : Form
    {
        double TotalPrice;
        int TotalCalorie;
        int TotalSodium;
        int TotalFat;
        int TotalProtein;
        public frmProject3()
        {
            InitializeComponent();
        }

        private void LblWaffleFries_Click(object sender, EventArgs e)
        {

        }

        private void LblDrPepper_Click(object sender, EventArgs e)
        {

        }

        private void TextBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void LblFat_Click(object sender, EventArgs e)
        {

        }

        private void LblProtein_Click(object sender, EventArgs e)
        {

        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            txtTotal.Clear();
            TotalPrice = 0;
            txtTotal.Text = "0.00";

            txtCal.Clear();
            TotalCalorie = 0;
            txtCal.Text = "0";

            txtFat.Clear();
            TotalFat = 0;
            txtFat.Text = "0";

            txtProtein.Clear();
            TotalProtein = 0;
            txtProtein.Text = "0";

            txtSodium.Clear();
            TotalSodium = 0;
            txtSodium.Text = "0";


            lstOrder.Items.Clear();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void PicSandwich_Click(object sender, EventArgs e)
        {
            lstOrder.Items.Add("Chicken Sandwich $3.15");

            TotalCalorie += 440;
            TotalFat += 19;
            TotalProtein += 28;
            TotalSodium += 1350;

            TotalPrice += 3.15;

            txtCal.Text = TotalCalorie.ToString() + " mg";
            txtFat.Text = TotalFat.ToString();
            txtProtein.Text = TotalProtein.ToString();
            txtSodium.Text = TotalSodium.ToString();

            txtTotal.Text = TotalPrice.ToString("c");
        }

        private void PicNuggets_Click(object sender, EventArgs e)
        {
            lstOrder.Items.Add("Chicken Nuggets $4.75");

            TotalCalorie += 260;
            TotalFat += 12;
            TotalProtein += 28;
            TotalSodium += 980;

            TotalPrice += 4.75;

            txtCal.Text = TotalCalorie.ToString() + " mg"; 
            txtFat.Text = TotalFat.ToString();
            txtProtein.Text = TotalProtein.ToString();
            txtSodium.Text = TotalSodium.ToString();

            txtTotal.Text = TotalPrice.ToString("c");

        }

        private void PicFries_Click(object sender, EventArgs e)
        {
            lstOrder.Items.Add("Waffle Fries $1.85");

            TotalCalorie += 365;
            TotalFat += 18;
            TotalProtein += 5;
            TotalSodium += 280;

            TotalPrice += 1.85;

            txtCal.Text = TotalCalorie.ToString() + " mg";
            txtFat.Text = TotalFat.ToString();
            txtProtein.Text = TotalProtein.ToString();
            txtSodium.Text = TotalSodium.ToString();

            txtTotal.Text = TotalPrice.ToString("c");

        }

        private void PicSalad_Click(object sender, EventArgs e)
        {

            lstOrder.Items.Add("Chicken Salad $ 7.19");

            TotalCalorie += 330;
            TotalFat += 14;
            TotalProtein += 27;
            TotalSodium += 670;

            TotalPrice += 7.19;

            txtCal.Text = TotalCalorie.ToString() + " mg";
            txtFat.Text = TotalFat.ToString();
            txtProtein.Text = TotalProtein.ToString();
            txtSodium.Text = TotalSodium.ToString();

            txtTotal.Text = TotalPrice.ToString("c");
        }

        private void PicCola_Click(object sender, EventArgs e)
        {
            lstOrder.Items.Add("Large Coca Cola $2.75");

            TotalCalorie += 260;
            TotalFat += 0;
            TotalProtein += 0;
            TotalSodium += 90;

            TotalPrice += 2.75;

            txtCal.Text = TotalCalorie.ToString() + " mg";
            txtFat.Text = TotalFat.ToString();
            txtProtein.Text = TotalProtein.ToString();
            txtSodium.Text = TotalSodium.ToString();

            txtTotal.Text = TotalPrice.ToString("c");
            
        }

        private void PicDrPepper_Click(object sender, EventArgs e)
        {
            lstOrder.Items.Add("Large Dr. Pepper $2.75");

            TotalCalorie += 260;
            TotalFat += 0;
            TotalProtein += 0;
            TotalSodium += 90;

            TotalPrice += 4.75;

            txtCal.Text = TotalCalorie.ToString() + " mg";
            txtFat.Text = TotalFat.ToString();
            txtProtein.Text = TotalProtein.ToString();
            txtSodium.Text = TotalSodium.ToString();

            txtTotal.Text = TotalPrice.ToString("c");
            
        }

        private void FrmProject3_Load(object sender, EventArgs e)
        {

        }
    }
}
