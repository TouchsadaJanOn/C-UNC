﻿namespace Project4JanOn
{
    partial class frmProject4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpLoops = new System.Windows.Forms.GroupBox();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.rbtnSumOfOdd = new System.Windows.Forms.RadioButton();
            this.rbtnProduct = new System.Windows.Forms.RadioButton();
            this.lblOutput = new System.Windows.Forms.Label();
            this.lblInput = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.grpTuition = new System.Windows.Forms.GroupBox();
            this.txtTotalCost = new System.Windows.Forms.TextBox();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.lstOutput = new System.Windows.Forms.ListBox();
            this.lblYear = new System.Windows.Forms.Label();
            this.btnCalculate2 = new System.Windows.Forms.Button();
            this.grpMillionaire = new System.Windows.Forms.GroupBox();
            this.txtInterestRate = new System.Windows.Forms.TextBox();
            this.txtTotalAmountOfYear = new System.Windows.Forms.TextBox();
            this.txtDeposite = new System.Windows.Forms.TextBox();
            this.lblDepositeAmount = new System.Windows.Forms.Label();
            this.lblAmountOfYears = new System.Windows.Forms.Label();
            this.lblInterestRate = new System.Windows.Forms.Label();
            this.btnCompute = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.grpLoops.SuspendLayout();
            this.grpTuition.SuspendLayout();
            this.grpMillionaire.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpLoops
            // 
            this.grpLoops.Controls.Add(this.txtOutput);
            this.grpLoops.Controls.Add(this.txtInput);
            this.grpLoops.Controls.Add(this.rbtnSumOfOdd);
            this.grpLoops.Controls.Add(this.rbtnProduct);
            this.grpLoops.Controls.Add(this.lblOutput);
            this.grpLoops.Controls.Add(this.lblInput);
            this.grpLoops.Controls.Add(this.btnCalculate);
            this.grpLoops.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpLoops.Location = new System.Drawing.Point(21, 13);
            this.grpLoops.Name = "grpLoops";
            this.grpLoops.Size = new System.Drawing.Size(694, 154);
            this.grpLoops.TabIndex = 0;
            this.grpLoops.TabStop = false;
            this.grpLoops.Text = "Loops";
            // 
            // txtOutput
            // 
            this.txtOutput.Location = new System.Drawing.Point(117, 93);
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.Size = new System.Drawing.Size(152, 24);
            this.txtOutput.TabIndex = 8;
            // 
            // txtInput
            // 
            this.txtInput.Location = new System.Drawing.Point(117, 44);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(152, 24);
            this.txtInput.TabIndex = 7;
            // 
            // rbtnSumOfOdd
            // 
            this.rbtnSumOfOdd.AutoSize = true;
            this.rbtnSumOfOdd.Location = new System.Drawing.Point(344, 95);
            this.rbtnSumOfOdd.Name = "rbtnSumOfOdd";
            this.rbtnSumOfOdd.Size = new System.Drawing.Size(119, 22);
            this.rbtnSumOfOdd.TabIndex = 6;
            this.rbtnSumOfOdd.TabStop = true;
            this.rbtnSumOfOdd.Text = "Sum Of Odd";
            this.rbtnSumOfOdd.UseVisualStyleBackColor = true;
            // 
            // rbtnProduct
            // 
            this.rbtnProduct.AutoSize = true;
            this.rbtnProduct.Location = new System.Drawing.Point(348, 50);
            this.rbtnProduct.Name = "rbtnProduct";
            this.rbtnProduct.Size = new System.Drawing.Size(85, 22);
            this.rbtnProduct.TabIndex = 5;
            this.rbtnProduct.TabStop = true;
            this.rbtnProduct.Text = "Product";
            this.rbtnProduct.UseVisualStyleBackColor = true;
            // 
            // lblOutput
            // 
            this.lblOutput.AutoSize = true;
            this.lblOutput.Location = new System.Drawing.Point(48, 97);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(63, 18);
            this.lblOutput.TabIndex = 2;
            this.lblOutput.Text = "Output:";
            // 
            // lblInput
            // 
            this.lblInput.AutoSize = true;
            this.lblInput.Location = new System.Drawing.Point(62, 50);
            this.lblInput.Name = "lblInput";
            this.lblInput.Size = new System.Drawing.Size(49, 18);
            this.lblInput.TabIndex = 1;
            this.lblInput.Text = "Input:";
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(527, 50);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(134, 48);
            this.btnCalculate.TabIndex = 0;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.BtnCalculate_Click);
            // 
            // grpTuition
            // 
            this.grpTuition.Controls.Add(this.txtTotalCost);
            this.grpTuition.Controls.Add(this.txtYear);
            this.grpTuition.Controls.Add(this.lblTotalCost);
            this.grpTuition.Controls.Add(this.lstOutput);
            this.grpTuition.Controls.Add(this.lblYear);
            this.grpTuition.Controls.Add(this.btnCalculate2);
            this.grpTuition.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpTuition.Location = new System.Drawing.Point(21, 180);
            this.grpTuition.Name = "grpTuition";
            this.grpTuition.Size = new System.Drawing.Size(694, 212);
            this.grpTuition.TabIndex = 1;
            this.grpTuition.TabStop = false;
            this.grpTuition.Text = "Display Tuition";
            // 
            // txtTotalCost
            // 
            this.txtTotalCost.Location = new System.Drawing.Point(160, 177);
            this.txtTotalCost.Name = "txtTotalCost";
            this.txtTotalCost.Size = new System.Drawing.Size(127, 24);
            this.txtTotalCost.TabIndex = 9;
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(457, 33);
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(103, 24);
            this.txtYear.TabIndex = 8;
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.AutoSize = true;
            this.lblTotalCost.Location = new System.Drawing.Point(72, 180);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(82, 18);
            this.lblTotalCost.TabIndex = 4;
            this.lblTotalCost.Text = "TotalCost";
            // 
            // lstOutput
            // 
            this.lstOutput.FormattingEnabled = true;
            this.lstOutput.ItemHeight = 18;
            this.lstOutput.Location = new System.Drawing.Point(31, 36);
            this.lstOutput.Name = "lstOutput";
            this.lstOutput.Size = new System.Drawing.Size(256, 130);
            this.lstOutput.TabIndex = 3;
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.Location = new System.Drawing.Point(351, 36);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(92, 18);
            this.lblYear.TabIndex = 2;
            this.lblYear.Text = "Enter Year:";
            // 
            // btnCalculate2
            // 
            this.btnCalculate2.Location = new System.Drawing.Point(527, 102);
            this.btnCalculate2.Name = "btnCalculate2";
            this.btnCalculate2.Size = new System.Drawing.Size(134, 48);
            this.btnCalculate2.TabIndex = 1;
            this.btnCalculate2.Text = "Calculate";
            this.btnCalculate2.UseVisualStyleBackColor = true;
            this.btnCalculate2.Click += new System.EventHandler(this.BtnCalculate2_Click);
            // 
            // grpMillionaire
            // 
            this.grpMillionaire.Controls.Add(this.txtInterestRate);
            this.grpMillionaire.Controls.Add(this.txtTotalAmountOfYear);
            this.grpMillionaire.Controls.Add(this.txtDeposite);
            this.grpMillionaire.Controls.Add(this.lblDepositeAmount);
            this.grpMillionaire.Controls.Add(this.lblAmountOfYears);
            this.grpMillionaire.Controls.Add(this.lblInterestRate);
            this.grpMillionaire.Controls.Add(this.btnCompute);
            this.grpMillionaire.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpMillionaire.Location = new System.Drawing.Point(21, 409);
            this.grpMillionaire.Name = "grpMillionaire";
            this.grpMillionaire.Size = new System.Drawing.Size(694, 197);
            this.grpMillionaire.TabIndex = 2;
            this.grpMillionaire.TabStop = false;
            this.grpMillionaire.Text = "Who wants to be a millionaire?";
            // 
            // txtInterestRate
            // 
            this.txtInterestRate.Location = new System.Drawing.Point(222, 42);
            this.txtInterestRate.Name = "txtInterestRate";
            this.txtInterestRate.Size = new System.Drawing.Size(152, 24);
            this.txtInterestRate.TabIndex = 10;
            // 
            // txtTotalAmountOfYear
            // 
            this.txtTotalAmountOfYear.Location = new System.Drawing.Point(222, 128);
            this.txtTotalAmountOfYear.Name = "txtTotalAmountOfYear";
            this.txtTotalAmountOfYear.Size = new System.Drawing.Size(152, 24);
            this.txtTotalAmountOfYear.TabIndex = 9;
            // 
            // txtDeposite
            // 
            this.txtDeposite.Location = new System.Drawing.Point(222, 86);
            this.txtDeposite.Name = "txtDeposite";
            this.txtDeposite.Size = new System.Drawing.Size(152, 24);
            this.txtDeposite.TabIndex = 8;
            // 
            // lblDepositeAmount
            // 
            this.lblDepositeAmount.AutoSize = true;
            this.lblDepositeAmount.Location = new System.Drawing.Point(62, 92);
            this.lblDepositeAmount.Name = "lblDepositeAmount";
            this.lblDepositeAmount.Size = new System.Drawing.Size(142, 18);
            this.lblDepositeAmount.TabIndex = 5;
            this.lblDepositeAmount.Text = "Deposite Amount:";
            // 
            // lblAmountOfYears
            // 
            this.lblAmountOfYears.AutoSize = true;
            this.lblAmountOfYears.Location = new System.Drawing.Point(28, 134);
            this.lblAmountOfYears.Name = "lblAmountOfYears";
            this.lblAmountOfYears.Size = new System.Drawing.Size(178, 18);
            this.lblAmountOfYears.TabIndex = 4;
            this.lblAmountOfYears.Text = "Total amount of years:";
            // 
            // lblInterestRate
            // 
            this.lblInterestRate.AutoSize = true;
            this.lblInterestRate.Location = new System.Drawing.Point(101, 45);
            this.lblInterestRate.Name = "lblInterestRate";
            this.lblInterestRate.Size = new System.Drawing.Size(103, 18);
            this.lblInterestRate.TabIndex = 3;
            this.lblInterestRate.Text = "Interest rate:";
            // 
            // btnCompute
            // 
            this.btnCompute.Location = new System.Drawing.Point(527, 77);
            this.btnCompute.Name = "btnCompute";
            this.btnCompute.Size = new System.Drawing.Size(134, 48);
            this.btnCompute.TabIndex = 2;
            this.btnCompute.Text = "Compute";
            this.btnCompute.UseVisualStyleBackColor = true;
            this.btnCompute.Click += new System.EventHandler(this.BtnCompute_Click);
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(305, 612);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(106, 28);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.Button2_Click);
            // 
            // frmProject4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(740, 653);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.grpMillionaire);
            this.Controls.Add(this.grpTuition);
            this.Controls.Add(this.grpLoops);
            this.Name = "frmProject4";
            this.Text = "Project 4";
            this.grpLoops.ResumeLayout(false);
            this.grpLoops.PerformLayout();
            this.grpTuition.ResumeLayout(false);
            this.grpTuition.PerformLayout();
            this.grpMillionaire.ResumeLayout(false);
            this.grpMillionaire.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpLoops;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.GroupBox grpTuition;
        private System.Windows.Forms.Button btnCalculate2;
        private System.Windows.Forms.GroupBox grpMillionaire;
        private System.Windows.Forms.Button btnCompute;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtOutput;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.RadioButton rbtnSumOfOdd;
        private System.Windows.Forms.RadioButton rbtnProduct;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.Label lblInput;
        private System.Windows.Forms.TextBox txtTotalCost;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.ListBox lstOutput;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.TextBox txtInterestRate;
        private System.Windows.Forms.TextBox txtTotalAmountOfYear;
        private System.Windows.Forms.TextBox txtDeposite;
        private System.Windows.Forms.Label lblDepositeAmount;
        private System.Windows.Forms.Label lblAmountOfYears;
        private System.Windows.Forms.Label lblInterestRate;
    }
}

