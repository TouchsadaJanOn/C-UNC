﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project4JanOn
{
    public partial class frmProject4 : Form
    {
        public frmProject4()
        {
            InitializeComponent();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnCalculate_Click(object sender, EventArgs e)
        {
            
            if (rbtnProduct.Checked == true)
            {
                int input = int.Parse(txtInput.Text);
                int count = 1;
                int output = 1;

                while (count <= input) {
                    output = count * output;
                    count++;
                    }
                txtOutput.Text = output.ToString();
            }
           
            else if (rbtnSumOfOdd.Checked == true)
                {
                int input = int.Parse(txtInput.Text);
                double sum = 0;
                double oddtotal = 0;
                for (int count1 = 1; count1 <= input; count1 += 2)
                    {
                        sum += count1;
                        oddtotal += sum;
                    }

                txtOutput.Text = oddtotal.ToString();
            }
        }

        private void BtnCalculate2_Click(object sender, EventArgs e)
        {
            int input = int.Parse(txtYear.Text);
            int yearNum = 0;
            double cost = 6000.00;
            double increase = 0.02;
            double totalCost = 0.0;
            double newtotal = 0.0;
            lstOutput.Items.Add("Year\tTuition");
            for (int year = 1; year <= input; year++)
            {
                if (year <= 1)
                {
                    lstOutput.Items.Add(year + "\t" + cost.ToString("c"));
                }
                else
                {
                    yearNum = year + yearNum;
                    cost = cost + (cost * increase);
                    totalCost += cost;
                    newtotal = 6000.00 + totalCost;
                    lstOutput.Items.Add(year + "\t" + cost.ToString("c"));
                }
                txtTotalCost.Text = newtotal.ToString("c");
               



                
                
            }
            
            

        }

        private void BtnCompute_Click(object sender, EventArgs e)
        {
            double interest = double.Parse(txtInterestRate.Text);
            double deposite = double.Parse(txtDeposite.Text);
            
            int million = 1000000;
            int year = 0;

            do
            {
                    deposite = deposite + (deposite * interest);
                    year++;

            }
            while (deposite <= million);
            txtTotalAmountOfYear.Text = year.ToString();
        }

    }
}
