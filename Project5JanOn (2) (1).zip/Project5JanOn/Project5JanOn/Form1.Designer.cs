﻿namespace Project5JanOn
{
    partial class frmProject5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProject5));
            this.lblShipCalc = new System.Windows.Forms.Label();
            this.lblWeight = new System.Windows.Forms.Label();
            this.lblDistance = new System.Windows.Forms.Label();
            this.lblCost = new System.Windows.Forms.Label();
            this.grpCarrier = new System.Windows.Forms.GroupBox();
            this.radFedEx = new System.Windows.Forms.RadioButton();
            this.radUps2 = new System.Windows.Forms.RadioButton();
            this.radUps = new System.Windows.Forms.RadioButton();
            this.txtWeight = new System.Windows.Forms.TextBox();
            this.txtDistance = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnShCost = new System.Windows.Forms.Button();
            this.lblShCost = new System.Windows.Forms.Label();
            this.lblNote = new System.Windows.Forms.Label();
            this.grpCarrier.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblShipCalc
            // 
            this.lblShipCalc.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.lblShipCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShipCalc.Location = new System.Drawing.Point(76, 33);
            this.lblShipCalc.Name = "lblShipCalc";
            this.lblShipCalc.Size = new System.Drawing.Size(720, 71);
            this.lblShipCalc.TabIndex = 0;
            this.lblShipCalc.Text = "Two Eight Seven Shipping Calculator";
            this.lblShipCalc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWeight
            // 
            this.lblWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWeight.Location = new System.Drawing.Point(78, 157);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.Size = new System.Drawing.Size(151, 23);
            this.lblWeight.TabIndex = 1;
            this.lblWeight.Text = "Package Weight:";
            // 
            // lblDistance
            // 
            this.lblDistance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDistance.Location = new System.Drawing.Point(77, 259);
            this.lblDistance.Name = "lblDistance";
            this.lblDistance.Size = new System.Drawing.Size(164, 23);
            this.lblDistance.TabIndex = 2;
            this.lblDistance.Text = "Shipping Distance:";
            // 
            // lblCost
            // 
            this.lblCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCost.Location = new System.Drawing.Point(632, 189);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(164, 23);
            this.lblCost.TabIndex = 3;
            this.lblCost.Text = "Shipping Cost:";
            // 
            // grpCarrier
            // 
            this.grpCarrier.Controls.Add(this.radFedEx);
            this.grpCarrier.Controls.Add(this.radUps2);
            this.grpCarrier.Controls.Add(this.radUps);
            this.grpCarrier.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpCarrier.Location = new System.Drawing.Point(297, 145);
            this.grpCarrier.Name = "grpCarrier";
            this.grpCarrier.Size = new System.Drawing.Size(280, 341);
            this.grpCarrier.TabIndex = 4;
            this.grpCarrier.TabStop = false;
            this.grpCarrier.Text = "Carrier";
            // 
            // radFedEx
            // 
            this.radFedEx.Image = ((System.Drawing.Image)(resources.GetObject("radFedEx.Image")));
            this.radFedEx.Location = new System.Drawing.Point(69, 132);
            this.radFedEx.Name = "radFedEx";
            this.radFedEx.Size = new System.Drawing.Size(158, 63);
            this.radFedEx.TabIndex = 2;
            this.radFedEx.TabStop = true;
            this.radFedEx.UseVisualStyleBackColor = true;
            // 
            // radUps2
            // 
            this.radUps2.Image = ((System.Drawing.Image)(resources.GetObject("radUps2.Image")));
            this.radUps2.Location = new System.Drawing.Point(69, 221);
            this.radUps2.Name = "radUps2";
            this.radUps2.Size = new System.Drawing.Size(158, 73);
            this.radUps2.TabIndex = 1;
            this.radUps2.TabStop = true;
            this.radUps2.UseVisualStyleBackColor = true;
            // 
            // radUps
            // 
            this.radUps.Image = ((System.Drawing.Image)(resources.GetObject("radUps.Image")));
            this.radUps.Location = new System.Drawing.Point(69, 44);
            this.radUps.Name = "radUps";
            this.radUps.Size = new System.Drawing.Size(130, 78);
            this.radUps.TabIndex = 0;
            this.radUps.TabStop = true;
            this.radUps.UseVisualStyleBackColor = true;
            // 
            // txtWeight
            // 
            this.txtWeight.Location = new System.Drawing.Point(82, 204);
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(159, 20);
            this.txtWeight.TabIndex = 5;
            // 
            // txtDistance
            // 
            this.txtDistance.Location = new System.Drawing.Point(82, 320);
            this.txtDistance.Name = "txtDistance";
            this.txtDistance.Size = new System.Drawing.Size(159, 20);
            this.txtDistance.TabIndex = 6;
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(82, 399);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(129, 40);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // btnShCost
            // 
            this.btnShCost.BackColor = System.Drawing.Color.Red;
            this.btnShCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShCost.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnShCost.Location = new System.Drawing.Point(606, 335);
            this.btnShCost.Name = "btnShCost";
            this.btnShCost.Size = new System.Drawing.Size(247, 40);
            this.btnShCost.TabIndex = 8;
            this.btnShCost.Text = "Calculate Shipping Price";
            this.btnShCost.UseVisualStyleBackColor = false;
            this.btnShCost.Click += new System.EventHandler(this.BtnShCost_Click);
            // 
            // lblShCost
            // 
            this.lblShCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShCost.ForeColor = System.Drawing.Color.Red;
            this.lblShCost.Location = new System.Drawing.Point(633, 245);
            this.lblShCost.Name = "lblShCost";
            this.lblShCost.Size = new System.Drawing.Size(163, 49);
            this.lblShCost.TabIndex = 9;
            this.lblShCost.Text = "$0.00";
            this.lblShCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNote
            // 
            this.lblNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNote.Location = new System.Drawing.Point(633, 294);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(201, 35);
            this.lblNote.TabIndex = 10;
            this.lblNote.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // frmProject5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(882, 561);
            this.Controls.Add(this.lblNote);
            this.Controls.Add(this.lblShCost);
            this.Controls.Add(this.btnShCost);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtDistance);
            this.Controls.Add(this.txtWeight);
            this.Controls.Add(this.grpCarrier);
            this.Controls.Add(this.lblCost);
            this.Controls.Add(this.lblDistance);
            this.Controls.Add(this.lblWeight);
            this.Controls.Add(this.lblShipCalc);
            this.Name = "frmProject5";
            this.Text = "Project 5";
            this.grpCarrier.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblShipCalc;
        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.Label lblDistance;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.GroupBox grpCarrier;
        private System.Windows.Forms.TextBox txtWeight;
        private System.Windows.Forms.TextBox txtDistance;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnShCost;
        private System.Windows.Forms.RadioButton radFedEx;
        private System.Windows.Forms.RadioButton radUps2;
        private System.Windows.Forms.RadioButton radUps;
        private System.Windows.Forms.Label lblShCost;
        private System.Windows.Forms.Label lblNote;
    }
}

