﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project5JanOn
{
    public partial class frmProject5 : Form
    {
        double Distance;
        double Weight;
        double total;
        double additional;
        public frmProject5()
        {
            InitializeComponent();
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            Distance = 0;
            Weight = 0;
            total = 0;
            additional = 0;
            txtDistance.Clear();
            txtWeight.Clear();
            lblShCost.Text = "$0.00";
            radFedEx.Checked = false;
            radUps.Checked = false;
            radUps2.Checked = false;
            lblNote.Visible = false;
        }
        private double Ups(double Weight, double Distance)
        {
            if (Distance >= 0 && Distance <= 100)
            {
                total = Weight * 6.40;
            }
            else if (Distance >= 101 && Distance <= 500)
            {
                total = Weight * 5.75;
            }
            else
            {
                total = Weight * 4.50;
            }
            return total;
        }
        private double Fedex(double Weight, double Distance)
        { 
            if (Distance >= 0 && Distance <= 500)
            {
                total = Weight * 4.75;
            }
            else if (Distance >= 501 && Distance <= 1000)
            {
                total = Weight * 9.75;
            }
            else
            {
                total = Weight * 14.50;
            }
            return total;
        }
        private double Ups2(double Weight, double Distance)
        {
                if (Distance >= 500)
                {
                    additional = 1.25;
                    lblNote.Visible = true;
                    lblNote.Text = "Note: Milege upcharge of " + Weight * additional;
                }
                if (Weight <= 1)
                {
                    total = Weight * (3.90 + additional);
                }
                else if (Weight <= 10)
                {
                    total = Weight * (1.75 + additional);
                }
                else if (Weight <= 25)
                {
                    total = Weight * (1.50 + additional);
                }
                
                return total;
          


        }
        private void BtnShCost_Click(object sender, EventArgs e)
        {
            try
            {
                double Distance = double.Parse(txtDistance.Text);
                double Weight = double.Parse(txtWeight.Text);
                if (Distance < 0 || Weight < 0)
                {
                    MessageBox.Show("Error-input must be greater than 0");
                    lblShCost.Text = "$0.00";
                }
                else
                {

                    if (radUps.Checked == true)
                    {
                        Ups(Weight, Distance);
                    }

                    else if (radUps2.Checked == true && Weight <= 25)
                    {
                        Ups2(Weight, Distance);
                    }
                    else if (radUps2.Checked == true && Weight > 25)
                    {

                        MessageBox.Show("Error - The max shipping weight is 25 pounds for USPS");

                    }
                    else if (radFedEx.Checked == true)
                    {
                        Fedex(Weight, Distance);
                    }
                    else
                    {
                        MessageBox.Show("Error- you have to select a carrier");
                    }


                    lblShCost.Text = total.ToString("c");
                }
            }
            catch
            {
                MessageBox.Show("Error – input must be a numeric value");
            }
        }
    }
}
