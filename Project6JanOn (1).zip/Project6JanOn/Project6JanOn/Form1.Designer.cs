﻿namespace Project6JanOn
{
    partial class frmProject6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClear = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblTotalTeams = new System.Windows.Forms.Label();
            this.lstTeam = new System.Windows.Forms.ListBox();
            this.grpFilter = new System.Windows.Forms.GroupBox();
            this.cmbfilter = new System.Windows.Forms.ComboBox();
            this.lblFilter = new System.Windows.Forms.Label();
            this.grpYear = new System.Windows.Forms.GroupBox();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.lblYear = new System.Windows.Forms.Label();
            this.grpChamps = new System.Windows.Forms.GroupBox();
            this.txtCal = new System.Windows.Forms.TextBox();
            this.btnCal = new System.Windows.Forms.Button();
            this.lblChamps = new System.Windows.Forms.Label();
            this.grpFilter.SuspendLayout();
            this.grpYear.SuspendLayout();
            this.grpChamps.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(620, 46);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(114, 28);
            this.btnClear.TabIndex = 0;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(122, 39);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(431, 35);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "MLB World Series Data Set";
            // 
            // lblTotalTeams
            // 
            this.lblTotalTeams.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalTeams.Location = new System.Drawing.Point(74, 107);
            this.lblTotalTeams.Name = "lblTotalTeams";
            this.lblTotalTeams.Size = new System.Drawing.Size(203, 29);
            this.lblTotalTeams.TabIndex = 2;
            this.lblTotalTeams.Text = "Total Teams";
            this.lblTotalTeams.Click += new System.EventHandler(this.LblTotalTeams_Click);
            // 
            // lstTeam
            // 
            this.lstTeam.FormattingEnabled = true;
            this.lstTeam.Location = new System.Drawing.Point(27, 139);
            this.lstTeam.Name = "lstTeam";
            this.lstTeam.Size = new System.Drawing.Size(250, 407);
            this.lstTeam.TabIndex = 3;
            this.lstTeam.SelectedIndexChanged += new System.EventHandler(this.ListBox1_SelectedIndexChanged);
            // 
            // grpFilter
            // 
            this.grpFilter.BackColor = System.Drawing.Color.White;
            this.grpFilter.Controls.Add(this.cmbfilter);
            this.grpFilter.Controls.Add(this.lblFilter);
            this.grpFilter.Location = new System.Drawing.Point(300, 139);
            this.grpFilter.Name = "grpFilter";
            this.grpFilter.Size = new System.Drawing.Size(444, 100);
            this.grpFilter.TabIndex = 4;
            this.grpFilter.TabStop = false;
            // 
            // cmbfilter
            // 
            this.cmbfilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbfilter.FormattingEnabled = true;
            this.cmbfilter.Items.AddRange(new object[] {
            "Ascending",
            "Descending",
            "Winners with Years",
            "Deduplicated",
            "One-time Champs"});
            this.cmbfilter.Location = new System.Drawing.Point(191, 44);
            this.cmbfilter.Name = "cmbfilter";
            this.cmbfilter.Size = new System.Drawing.Size(209, 28);
            this.cmbfilter.TabIndex = 1;
            this.cmbfilter.Text = "Select an Item";
            this.cmbfilter.SelectedIndexChanged += new System.EventHandler(this.Cmbfilter_SelectedIndexChanged);
            // 
            // lblFilter
            // 
            this.lblFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFilter.Location = new System.Drawing.Point(34, 40);
            this.lblFilter.Name = "lblFilter";
            this.lblFilter.Size = new System.Drawing.Size(151, 22);
            this.lblFilter.TabIndex = 0;
            this.lblFilter.Text = "Select a filter: ";
            // 
            // grpYear
            // 
            this.grpYear.BackColor = System.Drawing.Color.White;
            this.grpYear.Controls.Add(this.txtYear);
            this.grpYear.Controls.Add(this.btnSubmit);
            this.grpYear.Controls.Add(this.lblYear);
            this.grpYear.Location = new System.Drawing.Point(300, 437);
            this.grpYear.Name = "grpYear";
            this.grpYear.Size = new System.Drawing.Size(444, 100);
            this.grpYear.TabIndex = 5;
            this.grpYear.TabStop = false;
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(47, 48);
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(205, 20);
            this.txtYear.TabIndex = 9;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(299, 40);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(114, 28);
            this.btnSubmit.TabIndex = 6;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.BtnSubmit_Click);
            // 
            // lblYear
            // 
            this.lblYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYear.Location = new System.Drawing.Point(43, 16);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(214, 22);
            this.lblYear.TabIndex = 1;
            this.lblYear.Text = "Who won this year?";
            // 
            // grpChamps
            // 
            this.grpChamps.BackColor = System.Drawing.Color.White;
            this.grpChamps.Controls.Add(this.txtCal);
            this.grpChamps.Controls.Add(this.btnCal);
            this.grpChamps.Controls.Add(this.lblChamps);
            this.grpChamps.Location = new System.Drawing.Point(300, 278);
            this.grpChamps.Name = "grpChamps";
            this.grpChamps.Size = new System.Drawing.Size(444, 100);
            this.grpChamps.TabIndex = 5;
            this.grpChamps.TabStop = false;
            // 
            // txtCal
            // 
            this.txtCal.Location = new System.Drawing.Point(47, 59);
            this.txtCal.Name = "txtCal";
            this.txtCal.Size = new System.Drawing.Size(205, 20);
            this.txtCal.TabIndex = 8;
            // 
            // btnCal
            // 
            this.btnCal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCal.Location = new System.Drawing.Point(299, 54);
            this.btnCal.Name = "btnCal";
            this.btnCal.Size = new System.Drawing.Size(114, 28);
            this.btnCal.TabIndex = 7;
            this.btnCal.Text = "Calculate";
            this.btnCal.UseVisualStyleBackColor = true;
            this.btnCal.Click += new System.EventHandler(this.BtnCal_Click);
            // 
            // lblChamps
            // 
            this.lblChamps.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChamps.Location = new System.Drawing.Point(24, 16);
            this.lblChamps.Name = "lblChamps";
            this.lblChamps.Size = new System.Drawing.Size(404, 22);
            this.lblChamps.TabIndex = 2;
            this.lblChamps.Text = "Who has won this many championships?";
            // 
            // frmProject6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 575);
            this.Controls.Add(this.grpYear);
            this.Controls.Add(this.grpChamps);
            this.Controls.Add(this.grpFilter);
            this.Controls.Add(this.lstTeam);
            this.Controls.Add(this.lblTotalTeams);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnClear);
            this.Name = "frmProject6";
            this.Text = "Project 6";
            this.grpFilter.ResumeLayout(false);
            this.grpYear.ResumeLayout(false);
            this.grpYear.PerformLayout();
            this.grpChamps.ResumeLayout(false);
            this.grpChamps.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblTotalTeams;
        private System.Windows.Forms.ListBox lstTeam;
        private System.Windows.Forms.GroupBox grpFilter;
        private System.Windows.Forms.Label lblFilter;
        private System.Windows.Forms.GroupBox grpYear;
        private System.Windows.Forms.GroupBox grpChamps;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label lblChamps;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnCal;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.TextBox txtCal;
        private System.Windows.Forms.ComboBox cmbfilter;
    }
}

