﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Project6JanOn
{

    public partial class frmProject6 : Form
    {
        string[] teams = File.ReadAllLines("teams.txt");
        string[] yearwinner = File.ReadAllLines("YearsWinners.txt");
        string Num;

        public frmProject6()
        {
            InitializeComponent();
        }

        private void LblTotalTeams_Click(object sender, EventArgs e)
        {

        }

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private string Allteams()
        {
            if (cmbfilter.SelectedItem.Equals("Ascending") == true)
            {
                Num = lstTeam.Items.Count.ToString();
                return Num;
            }
            else if (cmbfilter.SelectedItem.Equals("Descending") == true)
            {
                Num = lstTeam.Items.Count.ToString();
                return Num;
            }
            else if (cmbfilter.SelectedItem.Equals("Winners with Years") == true)
            {
                Num = lstTeam.Items.Count.ToString();
                return Num;
            }
            else if (cmbfilter.SelectedItem.Equals("Deduplicated") == true)
            {
                Num = lstTeam.Items.Count.ToString();
                return Num;
            }
            else
            {
                if (cmbfilter.SelectedItem.Equals("One-time Champs") == true)
                    Num = lstTeam.Items.Count.ToString();
                return Num;
            }
        }

        private void Cmbfilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbfilter.SelectedItem.Equals("Ascending") == true)
            {
                lstTeam.Items.Clear();
                var ascendQuery = from i in teams
                                  orderby i ascending
                                  select i;
                foreach (string n in ascendQuery)
                {
                    lstTeam.Items.Add(n);
                }
            }
            if (cmbfilter.SelectedItem.Equals("Descending") == true)
            {
                lstTeam.Items.Clear();
                var descendQuery = from j in teams
                                   orderby j descending
                                   select j;
                foreach (string n in descendQuery)
                {
                    lstTeam.Items.Add(n);
                }
            }
            if (cmbfilter.SelectedItem.Equals("Winners with Years") == true)
            {
                lstTeam.Items.Clear();
                var teambyyear = from year in yearwinner
                                 let winyear = year.Split('|')
                                 let time = winyear[0]
                                 let name = winyear[1]
                                 select new { time, name };

                foreach (var team in teambyyear)
                {
                    lstTeam.Items.Add("In " + team.time + " the winner was " + team.name);
                }
            }
            if (cmbfilter.SelectedItem.Equals("Deduplicated") == true)
            {
                lstTeam.Items.Clear();
                var oneQuery = (from k in teams
                                select k).Distinct();
                foreach (var n in oneQuery)
                {
                    lstTeam.Items.Add(n);
                }

            }
            if (cmbfilter.SelectedItem.Equals("One-time Champs") == true)
            {
                
                lstTeam.Items.Clear();
                double numchamps = 1;

                List<string> teamcounter = new List<string>();

                foreach (string i in teams)
                {
                    for (int counter = 0; counter < teams.Length; counter++)
                    {
                        if (teams[counter] == i)
                        {
                            teamcounter.Add(teams[counter]);
                        }
                    }
                    if (teamcounter.Count == numchamps)
                    {
                        lstTeam.Items.Add(teamcounter[0]);
                    }
                    teamcounter.Clear();

                }

            }
            Allteams();
            lblTotalTeams.Text = (Num + " Total teams");
        }

    private void BtnClear_Click(object sender, EventArgs e)
        {
            lblTotalTeams.Text = "Total Teams.";
            lstTeam.Items.Clear();
            txtCal.Clear();
            txtYear.Clear();
            
        }
        private void total()
        {
            lblTotalTeams.Text = lstTeam.Items.Count.ToString() + " Total Teams.";
        }
        private void BtnCal_Click(object sender, EventArgs e)
        {
            
            try
            {
                int numchamps = int.Parse(txtCal.Text);
                List<string> teamcounter = new List<string>();
                foreach (string i in teams)
                {
                    for (int counter = 0; counter < teams.Length; counter++)
                    {
                        if (teams[counter] == i)
                        {
                            teamcounter.Add(teams[counter]);
                        }
                    }
                    if (teamcounter.Count == numchamps)
                    {
                        if (!lstTeam.Items.Contains(teamcounter[0]))
                        {
                            lstTeam.Items.Add(teamcounter[0]);
                        }
                    }
                    total();
                    teamcounter.Clear();
       

                }
                if (numchamps < 0)
                {
                    MessageBox.Show("Number of championships must be greater than 0");
                }
            }

            catch
            {
                MessageBox.Show("Must be a numeric number");
            }
            
        }

        private void BtnSubmit_Click(object sender, EventArgs e)
        {
            double wonyear = double.Parse(txtYear.Text);
            if (wonyear > 1902 & wonyear <= 2019)
            {
                lstTeam.Items.Clear();
                string yearEntered = txtYear.Text;

                var teambyyear = from year in yearwinner
                                 let winyear = year.Split('|')
                                 let time = winyear[0]
                                 let name = winyear[1]
                                 select new { time, name };
                foreach (var j in teambyyear)
                {
                    if (yearEntered == j.time)
                    {
                        lstTeam.Items.Add("In " + j.time + " the winner was the: " + j.name);
                    }
                }
                total();
            }
            else
            {
                MessageBox.Show("Please enter a year between 1903 and 2020");
                txtYear.Text = "";
            }

        }
    }
}
