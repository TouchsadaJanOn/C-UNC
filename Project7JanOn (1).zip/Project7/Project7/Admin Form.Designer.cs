﻿namespace Project7
{
    partial class Admin_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAdminTotal = new System.Windows.Forms.Label();
            this.grpRemaining = new System.Windows.Forms.GroupBox();
            this.lblDisplayClub = new System.Windows.Forms.Label();
            this.lblDisplayUpper = new System.Windows.Forms.Label();
            this.lblDisplayLower = new System.Windows.Forms.Label();
            this.lblAdUpperD = new System.Windows.Forms.Label();
            this.lblAdminClub = new System.Windows.Forms.Label();
            this.lblAdminLowerL = new System.Windows.Forms.Label();
            this.grpGuestLookUp = new System.Windows.Forms.GroupBox();
            this.txtConfirm = new System.Windows.Forms.TextBox();
            this.lblConfirmationNum = new System.Windows.Forms.Label();
            this.btnFind = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Customers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Total_Cost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Confirmation_Number = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Lower_Level_Seats = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Club_Level_Seats = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Upper_Deck_Seats = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnClose = new System.Windows.Forms.Button();
            this.grpRemaining.SuspendLayout();
            this.grpGuestLookUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblAdminTotal
            // 
            this.lblAdminTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminTotal.ForeColor = System.Drawing.Color.Red;
            this.lblAdminTotal.Location = new System.Drawing.Point(34, 9);
            this.lblAdminTotal.Name = "lblAdminTotal";
            this.lblAdminTotal.Size = new System.Drawing.Size(572, 53);
            this.lblAdminTotal.TabIndex = 0;
            this.lblAdminTotal.Text = "Total Sales";
            this.lblAdminTotal.Click += new System.EventHandler(this.lblAdminTotal_Click);
            // 
            // grpRemaining
            // 
            this.grpRemaining.Controls.Add(this.lblDisplayClub);
            this.grpRemaining.Controls.Add(this.lblDisplayUpper);
            this.grpRemaining.Controls.Add(this.lblDisplayLower);
            this.grpRemaining.Controls.Add(this.lblAdUpperD);
            this.grpRemaining.Controls.Add(this.lblAdminClub);
            this.grpRemaining.Controls.Add(this.lblAdminLowerL);
            this.grpRemaining.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpRemaining.Location = new System.Drawing.Point(44, 65);
            this.grpRemaining.Name = "grpRemaining";
            this.grpRemaining.Size = new System.Drawing.Size(590, 195);
            this.grpRemaining.TabIndex = 1;
            this.grpRemaining.TabStop = false;
            this.grpRemaining.Text = "Seats Remaining";
            // 
            // lblDisplayClub
            // 
            this.lblDisplayClub.AutoSize = true;
            this.lblDisplayClub.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDisplayClub.Location = new System.Drawing.Point(223, 109);
            this.lblDisplayClub.Name = "lblDisplayClub";
            this.lblDisplayClub.Size = new System.Drawing.Size(27, 29);
            this.lblDisplayClub.TabIndex = 5;
            this.lblDisplayClub.Text = "0";
            // 
            // lblDisplayUpper
            // 
            this.lblDisplayUpper.AutoSize = true;
            this.lblDisplayUpper.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDisplayUpper.Location = new System.Drawing.Point(410, 109);
            this.lblDisplayUpper.Name = "lblDisplayUpper";
            this.lblDisplayUpper.Size = new System.Drawing.Size(27, 29);
            this.lblDisplayUpper.TabIndex = 4;
            this.lblDisplayUpper.Text = "0";
            // 
            // lblDisplayLower
            // 
            this.lblDisplayLower.AutoSize = true;
            this.lblDisplayLower.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDisplayLower.Location = new System.Drawing.Point(21, 109);
            this.lblDisplayLower.Name = "lblDisplayLower";
            this.lblDisplayLower.Size = new System.Drawing.Size(27, 29);
            this.lblDisplayLower.TabIndex = 3;
            this.lblDisplayLower.Text = "0";
            // 
            // lblAdUpperD
            // 
            this.lblAdUpperD.AutoSize = true;
            this.lblAdUpperD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdUpperD.Location = new System.Drawing.Point(410, 61);
            this.lblAdUpperD.Name = "lblAdUpperD";
            this.lblAdUpperD.Size = new System.Drawing.Size(158, 29);
            this.lblAdUpperD.TabIndex = 2;
            this.lblAdUpperD.Text = "Upper Deck:";
            // 
            // lblAdminClub
            // 
            this.lblAdminClub.AutoSize = true;
            this.lblAdminClub.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminClub.Location = new System.Drawing.Point(223, 61);
            this.lblAdminClub.Name = "lblAdminClub";
            this.lblAdminClub.Size = new System.Drawing.Size(144, 29);
            this.lblAdminClub.TabIndex = 1;
            this.lblAdminClub.Text = "Club Level:";
            // 
            // lblAdminLowerL
            // 
            this.lblAdminLowerL.AutoSize = true;
            this.lblAdminLowerL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminLowerL.Location = new System.Drawing.Point(21, 61);
            this.lblAdminLowerL.Name = "lblAdminLowerL";
            this.lblAdminLowerL.Size = new System.Drawing.Size(162, 29);
            this.lblAdminLowerL.TabIndex = 0;
            this.lblAdminLowerL.Text = "Lower Level:";
            // 
            // grpGuestLookUp
            // 
            this.grpGuestLookUp.Controls.Add(this.txtConfirm);
            this.grpGuestLookUp.Controls.Add(this.lblConfirmationNum);
            this.grpGuestLookUp.Controls.Add(this.btnFind);
            this.grpGuestLookUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpGuestLookUp.Location = new System.Drawing.Point(658, 65);
            this.grpGuestLookUp.Name = "grpGuestLookUp";
            this.grpGuestLookUp.Size = new System.Drawing.Size(590, 195);
            this.grpGuestLookUp.TabIndex = 2;
            this.grpGuestLookUp.TabStop = false;
            this.grpGuestLookUp.Text = "Guest Lookup";
            this.grpGuestLookUp.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // txtConfirm
            // 
            this.txtConfirm.Location = new System.Drawing.Point(299, 61);
            this.txtConfirm.Name = "txtConfirm";
            this.txtConfirm.Size = new System.Drawing.Size(255, 35);
            this.txtConfirm.TabIndex = 7;
            // 
            // lblConfirmationNum
            // 
            this.lblConfirmationNum.AutoSize = true;
            this.lblConfirmationNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfirmationNum.Location = new System.Drawing.Point(18, 61);
            this.lblConfirmationNum.Name = "lblConfirmationNum";
            this.lblConfirmationNum.Size = new System.Drawing.Size(275, 29);
            this.lblConfirmationNum.TabIndex = 6;
            this.lblConfirmationNum.Text = "Confirmation Number: ";
            // 
            // btnFind
            // 
            this.btnFind.BackColor = System.Drawing.Color.Cyan;
            this.btnFind.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFind.Location = new System.Drawing.Point(207, 114);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(189, 57);
            this.btnFind.TabIndex = 5;
            this.btnFind.Text = "Find";
            this.btnFind.UseVisualStyleBackColor = false;
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Customers,
            this.Email,
            this.Total_Cost,
            this.Confirmation_Number,
            this.Lower_Level_Seats,
            this.Club_Level_Seats,
            this.Upper_Deck_Seats});
            this.dataGridView1.Location = new System.Drawing.Point(89, 273);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1113, 334);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Customers
            // 
            this.Customers.HeaderText = "Customers";
            this.Customers.MinimumWidth = 8;
            this.Customers.Name = "Customers";
            this.Customers.Width = 150;
            // 
            // Email
            // 
            this.Email.HeaderText = "Email";
            this.Email.MinimumWidth = 8;
            this.Email.Name = "Email";
            this.Email.Width = 150;
            // 
            // Total_Cost
            // 
            this.Total_Cost.HeaderText = "Total_Cost";
            this.Total_Cost.MinimumWidth = 8;
            this.Total_Cost.Name = "Total_Cost";
            this.Total_Cost.Width = 150;
            // 
            // Confirmation_Number
            // 
            this.Confirmation_Number.HeaderText = "Confirmation_Number";
            this.Confirmation_Number.MinimumWidth = 8;
            this.Confirmation_Number.Name = "Confirmation_Number";
            this.Confirmation_Number.Width = 150;
            // 
            // Lower_Level_Seats
            // 
            this.Lower_Level_Seats.HeaderText = "Lower_Level_Seats";
            this.Lower_Level_Seats.MinimumWidth = 8;
            this.Lower_Level_Seats.Name = "Lower_Level_Seats";
            this.Lower_Level_Seats.Width = 150;
            // 
            // Club_Level_Seats
            // 
            this.Club_Level_Seats.HeaderText = "Club_Level_Seats";
            this.Club_Level_Seats.MinimumWidth = 8;
            this.Club_Level_Seats.Name = "Club_Level_Seats";
            this.Club_Level_Seats.Width = 150;
            // 
            // Upper_Deck_Seats
            // 
            this.Upper_Deck_Seats.HeaderText = "Upper_Deck_Seats";
            this.Upper_Deck_Seats.MinimumWidth = 8;
            this.Upper_Deck_Seats.Name = "Upper_Deck_Seats";
            this.Upper_Deck_Seats.Width = 150;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Cyan;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(544, 625);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(189, 57);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // Admin_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1276, 744);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.grpGuestLookUp);
            this.Controls.Add(this.grpRemaining);
            this.Controls.Add(this.lblAdminTotal);
            this.Name = "Admin_Form";
            this.Text = "Admin_Form";
            this.Load += new System.EventHandler(this.Admin_Form_Load);
            this.grpRemaining.ResumeLayout(false);
            this.grpRemaining.PerformLayout();
            this.grpGuestLookUp.ResumeLayout(false);
            this.grpGuestLookUp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblAdminTotal;
        private System.Windows.Forms.GroupBox grpRemaining;
        private System.Windows.Forms.GroupBox grpGuestLookUp;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblDisplayClub;
        private System.Windows.Forms.Label lblDisplayUpper;
        private System.Windows.Forms.Label lblDisplayLower;
        private System.Windows.Forms.Label lblAdUpperD;
        private System.Windows.Forms.Label lblAdminClub;
        private System.Windows.Forms.Label lblAdminLowerL;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblConfirmationNum;
        private System.Windows.Forms.TextBox txtConfirm;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customers;
        private System.Windows.Forms.DataGridViewTextBoxColumn Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn Total_Cost;
        private System.Windows.Forms.DataGridViewTextBoxColumn Confirmation_Number;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lower_Level_Seats;
        private System.Windows.Forms.DataGridViewTextBoxColumn Club_Level_Seats;
        private System.Windows.Forms.DataGridViewTextBoxColumn Upper_Deck_Seats;
    }
}