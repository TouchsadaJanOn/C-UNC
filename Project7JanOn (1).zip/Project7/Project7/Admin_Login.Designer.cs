﻿namespace Project7
{
    partial class Admin_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnadminLogin = new System.Windows.Forms.Button();
            this.lblAdminUser = new System.Windows.Forms.Label();
            this.lblAdminPass = new System.Windows.Forms.Label();
            this.txtAdminUser = new System.Windows.Forms.TextBox();
            this.txtAdminPass = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnadminLogin
            // 
            this.btnadminLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadminLogin.Location = new System.Drawing.Point(568, 77);
            this.btnadminLogin.Name = "btnadminLogin";
            this.btnadminLogin.Size = new System.Drawing.Size(142, 55);
            this.btnadminLogin.TabIndex = 0;
            this.btnadminLogin.Text = "Login";
            this.btnadminLogin.UseVisualStyleBackColor = true;
            this.btnadminLogin.Click += new System.EventHandler(this.btnadminLogin_Click);
            // 
            // lblAdminUser
            // 
            this.lblAdminUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminUser.Location = new System.Drawing.Point(51, 64);
            this.lblAdminUser.Name = "lblAdminUser";
            this.lblAdminUser.Size = new System.Drawing.Size(148, 34);
            this.lblAdminUser.TabIndex = 1;
            this.lblAdminUser.Text = "Username: ";
            // 
            // lblAdminPass
            // 
            this.lblAdminPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminPass.Location = new System.Drawing.Point(51, 119);
            this.lblAdminPass.Name = "lblAdminPass";
            this.lblAdminPass.Size = new System.Drawing.Size(148, 34);
            this.lblAdminPass.TabIndex = 2;
            this.lblAdminPass.Text = "Password: ";
            // 
            // txtAdminUser
            // 
            this.txtAdminUser.Location = new System.Drawing.Point(206, 64);
            this.txtAdminUser.Name = "txtAdminUser";
            this.txtAdminUser.Size = new System.Drawing.Size(311, 26);
            this.txtAdminUser.TabIndex = 3;
            // 
            // txtAdminPass
            // 
            this.txtAdminPass.Location = new System.Drawing.Point(206, 119);
            this.txtAdminPass.Name = "txtAdminPass";
            this.txtAdminPass.PasswordChar = '*';
            this.txtAdminPass.Size = new System.Drawing.Size(311, 26);
            this.txtAdminPass.TabIndex = 4;
            // 
            // Admin_Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(765, 214);
            this.Controls.Add(this.txtAdminPass);
            this.Controls.Add(this.txtAdminUser);
            this.Controls.Add(this.lblAdminPass);
            this.Controls.Add(this.lblAdminUser);
            this.Controls.Add(this.btnadminLogin);
            this.Name = "Admin_Login";
            this.Text = "Admin_Login";
            this.Load += new System.EventHandler(this.Admin_Login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnadminLogin;
        private System.Windows.Forms.Label lblAdminUser;
        private System.Windows.Forms.Label lblAdminPass;
        private System.Windows.Forms.TextBox txtAdminUser;
        private System.Windows.Forms.TextBox txtAdminPass;
    }
}