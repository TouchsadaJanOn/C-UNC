﻿namespace Project7
{
    partial class GetTicket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBandName = new System.Windows.Forms.Label();
            this.btnGetTicket = new System.Windows.Forms.Button();
            this.lnkAdmin = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // lblBandName
            // 
            this.lblBandName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBandName.Location = new System.Drawing.Point(109, 149);
            this.lblBandName.Name = "lblBandName";
            this.lblBandName.Size = new System.Drawing.Size(446, 59);
            this.lblBandName.TabIndex = 0;
            this.lblBandName.Text = "HourlyScaredPickle";
            // 
            // btnGetTicket
            // 
            this.btnGetTicket.BackColor = System.Drawing.Color.Cyan;
            this.btnGetTicket.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetTicket.Location = new System.Drawing.Point(205, 241);
            this.btnGetTicket.Name = "btnGetTicket";
            this.btnGetTicket.Size = new System.Drawing.Size(210, 80);
            this.btnGetTicket.TabIndex = 2;
            this.btnGetTicket.Text = "Get Tickets";
            this.btnGetTicket.UseVisualStyleBackColor = false;
            this.btnGetTicket.Click += new System.EventHandler(this.btnGetTicket_Click);
            // 
            // lnkAdmin
            // 
            this.lnkAdmin.AutoSize = true;
            this.lnkAdmin.Location = new System.Drawing.Point(58, 67);
            this.lnkAdmin.Name = "lnkAdmin";
            this.lnkAdmin.Size = new System.Drawing.Size(58, 20);
            this.lnkAdmin.TabIndex = 3;
            this.lnkAdmin.TabStop = true;
            this.lnkAdmin.Text = "Admin:";
            this.lnkAdmin.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkAdmin_LinkClicked);
            // 
            // GetTicket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(613, 450);
            this.Controls.Add(this.lnkAdmin);
            this.Controls.Add(this.btnGetTicket);
            this.Controls.Add(this.lblBandName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "GetTicket";
            this.Text = "Get Tickets";
            this.Load += new System.EventHandler(this.GetTicket_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBandName;
        private System.Windows.Forms.Button btnGetTicket;
        private System.Windows.Forms.LinkLabel lnkAdmin;
    }
}

