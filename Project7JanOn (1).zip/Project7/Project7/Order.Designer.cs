﻿namespace Project7
{
    partial class Order
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpOrder = new System.Windows.Forms.GroupBox();
            this.btnBuy = new System.Windows.Forms.Button();
            this.cmbUpper = new System.Windows.Forms.ComboBox();
            this.cmbClub = new System.Windows.Forms.ComboBox();
            this.cmbLower = new System.Windows.Forms.ComboBox();
            this.lblClub = new System.Windows.Forms.Label();
            this.lblUpper = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.lblLower = new System.Windows.Forms.Label();
            this.grpOrder.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpOrder
            // 
            this.grpOrder.Controls.Add(this.btnBuy);
            this.grpOrder.Controls.Add(this.cmbUpper);
            this.grpOrder.Controls.Add(this.cmbClub);
            this.grpOrder.Controls.Add(this.cmbLower);
            this.grpOrder.Controls.Add(this.lblClub);
            this.grpOrder.Controls.Add(this.lblUpper);
            this.grpOrder.Controls.Add(this.lblQuantity);
            this.grpOrder.Controls.Add(this.lblLower);
            this.grpOrder.Location = new System.Drawing.Point(63, 29);
            this.grpOrder.Name = "grpOrder";
            this.grpOrder.Size = new System.Drawing.Size(688, 394);
            this.grpOrder.TabIndex = 0;
            this.grpOrder.TabStop = false;
            this.grpOrder.Text = "Tickets";
            this.grpOrder.Enter += new System.EventHandler(this.grpOrder_Enter);
            // 
            // btnBuy
            // 
            this.btnBuy.BackColor = System.Drawing.Color.Cyan;
            this.btnBuy.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuy.Location = new System.Drawing.Point(240, 304);
            this.btnBuy.Name = "btnBuy";
            this.btnBuy.Size = new System.Drawing.Size(167, 58);
            this.btnBuy.TabIndex = 7;
            this.btnBuy.Text = "Buy";
            this.btnBuy.UseVisualStyleBackColor = false;
            this.btnBuy.Click += new System.EventHandler(this.btnBuy_Click);
            // 
            // cmbUpper
            // 
            this.cmbUpper.FormattingEnabled = true;
            this.cmbUpper.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9"});
            this.cmbUpper.Location = new System.Drawing.Point(372, 242);
            this.cmbUpper.Name = "cmbUpper";
            this.cmbUpper.Size = new System.Drawing.Size(255, 28);
            this.cmbUpper.TabIndex = 6;
            // 
            // cmbClub
            // 
            this.cmbClub.FormattingEnabled = true;
            this.cmbClub.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9"});
            this.cmbClub.Location = new System.Drawing.Point(372, 171);
            this.cmbClub.Name = "cmbClub";
            this.cmbClub.Size = new System.Drawing.Size(255, 28);
            this.cmbClub.TabIndex = 5;
            // 
            // cmbLower
            // 
            this.cmbLower.FormattingEnabled = true;
            this.cmbLower.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9"});
            this.cmbLower.Location = new System.Drawing.Point(372, 100);
            this.cmbLower.Name = "cmbLower";
            this.cmbLower.Size = new System.Drawing.Size(255, 28);
            this.cmbLower.TabIndex = 4;
            this.cmbLower.SelectedIndexChanged += new System.EventHandler(this.cmbLower_SelectedIndexChanged);
            // 
            // lblClub
            // 
            this.lblClub.AutoSize = true;
            this.lblClub.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClub.Location = new System.Drawing.Point(29, 171);
            this.lblClub.Name = "lblClub";
            this.lblClub.Size = new System.Drawing.Size(228, 29);
            this.lblClub.TabIndex = 3;
            this.lblClub.Text = "Club Level: $75.00";
            this.lblClub.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblUpper
            // 
            this.lblUpper.AutoSize = true;
            this.lblUpper.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpper.Location = new System.Drawing.Point(29, 242);
            this.lblUpper.Name = "lblUpper";
            this.lblUpper.Size = new System.Drawing.Size(242, 29);
            this.lblUpper.TabIndex = 2;
            this.lblUpper.Text = "Upper Deck: $50.00";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantity.Location = new System.Drawing.Point(512, 38);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(115, 29);
            this.lblQuantity.TabIndex = 1;
            this.lblQuantity.Text = "Quantity:";
            // 
            // lblLower
            // 
            this.lblLower.AutoSize = true;
            this.lblLower.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLower.Location = new System.Drawing.Point(29, 100);
            this.lblLower.Name = "lblLower";
            this.lblLower.Size = new System.Drawing.Size(260, 29);
            this.lblLower.TabIndex = 0;
            this.lblLower.Text = "Lower Level: $125.00";
            // 
            // Order
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(818, 450);
            this.Controls.Add(this.grpOrder);
            this.Name = "Order";
            this.ShowInTaskbar = false;
            this.Text = "Order";
            this.Load += new System.EventHandler(this.Order_Load);
            this.grpOrder.ResumeLayout(false);
            this.grpOrder.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpOrder;
        private System.Windows.Forms.Label lblClub;
        private System.Windows.Forms.Label lblUpper;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lblLower;
        private System.Windows.Forms.Button btnBuy;
        private System.Windows.Forms.ComboBox cmbUpper;
        private System.Windows.Forms.ComboBox cmbClub;
        private System.Windows.Forms.ComboBox cmbLower;
    }
}